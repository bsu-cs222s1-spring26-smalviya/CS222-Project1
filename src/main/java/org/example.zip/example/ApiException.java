package org.example;

public class ApiException extends WikiException {
    public ApiException(String message) {
        super(message);
    }

}

package org.example;

public class NetworkException extends WikiException {
    public NetworkException(String message, Throwable cause){
        super(message, cause);

    }

}

package org.example;

public class NotFoundException extends WikiException
{
    public NotFoundException(String message)
    {
        super(message);
    }
}

package org.example;

public class ParseException extends WikiException{
    public ParseException(String message){
        super(message);
    }
}
